<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        echo '小瓜官网施工中，更多内容请关注npuxiaogua';
    }
}
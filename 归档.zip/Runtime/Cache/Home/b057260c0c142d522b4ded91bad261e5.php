<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class="enroll_success">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="user-scalable=no,width=device-width,initial-scale=1,maximum-scale=1"/>
    <link rel="stylesheet" type="text/css" href="/Public/css/style.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/style-responsive.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/home.css" />
    <title>契约情侣报名成功！</title>
</head>

<body class="login">
<div class="container">

    <section class="error-wrapper text-center">
        <h1><img alt="" src="/Public/pic/res/xiaogualogo-transparent.png"></h1>

        <h2>报名成功！</h2>

        <a class="back-btn" href="<?php echo U('Home/App/enroll');?>">再助攻个室友吧</a>
    </section>

</div>


<script type="text/javascript" src="/Public/js/jquery.min.js"></script>
<script type="text/javascript" src="/Public/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="/Public/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/Public/js/jquery.nicescroll.js"></script>
<script type="text/javascript" src="/Public/js/index.js"></script>


<script type="text/javascript" src="/Public/js/app_enroll.js"></script>
<script>

</script>
</body>

</html>
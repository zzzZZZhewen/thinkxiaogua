模块：

Home (微信主页模块）
 -IndexController 主页展示控制器
 -BlogController 
 -NewsController
 -AppController 网站小应用控制器
    -enlist 注册功能
 -UserController 用户页面展示控制器
 -UserCoreController 需要用户登录的控制器基类
Admin（管理员模块）
